/***************************************************************************
***
***    Copyright (C) 2012-2019 UfiSpace, Inc.
***    All Rights Reserved.
***    No portions of this material shall be reproduced in any form without
***    the written permission of Ufispace, Inc.
***
***    All information contained in this document is Ufispace, Inc. company
***    private, proprietary, and trade secret property and are protected by
***    international intellectual property laws and treaties.
***
****************************************************************************
***
***    FILE NAME :
***      ioset.c
***
***    DESCRIPTION :
***      for setting IO
***
***    HISTORY :
***       - 2018/03/12, 08:53:23, Jeff Yen
***             File Creation
***
***************************************************************************/

/*==========================================================================
 *
 *      Library Inclusion Segment
 *
 *==========================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#include "lpc_hal.h"

/*==========================================================================
 *
 *      Constant
 *
 *==========================================================================
 */

/*==========================================================================
 *
 *      Structrue segment
 *
 *==========================================================================
 */

/*==========================================================================
 *
 *      Static Variable segment
 *
 *==========================================================================
 */

/*==========================================================================
 *
 *      Function Definition Segment
 *
 *==========================================================================
 */

/*==========================================================================
 *
 *      Local Function Body segment
 *
 *==========================================================================
 */

/*==========================================================================
 *
 *      External Funtion Body segment
 *
 *==========================================================================
*/
void cmd_help (INT32 err)
{
    switch (err) {
        case E_TYPE_INVALID_CMD_FORMAT:
        case E_TYPE_INVALID_PARA:
        case E_TYPE_INVALID_ADDR:
            printf("Version : 1.1\n");
            printf("Usage: <ioset> <address> <value>\n");
            printf("     ioset   : ioset tool path\n");
            printf("     address : the target address are \n");
            printf("               0x600 is base of CPU board CPLD,\n");
            printf("               0x700 is base of switch board CPLD.\n");
            printf("     value   : the value what to set to register\n\n");
            break;

        default:
            break;
    }
}

int main(INT32 argc, INT8 *argv[])
{
    INT32  ret = E_TYPE_SUCCESS;
    UINT32 addr = 0;
    UINT8  value;

    if (argc != 3) {
        ret = E_TYPE_INVALID_CMD_FORMAT;
        goto __CMD_ERROR;
    }

    addr = strtoul(argv[1], NULL, 16);
    value = (UINT8)strtoul(argv[2], NULL, 16);

    if (((addr & LPC_DEVICE_ADDR) != LPC_DEVICE_ADDR) &&
        ((addr & DNX_QAX_LPC_CPLD_ADDR) != DNX_QAX_LPC_CPLD_ADDR)) {
        printf("Invalid address: 0x%x\n", addr);
        ret = E_TYPE_INVALID_ADDR;
        goto __CMD_ERROR;
    }

    ret = lpc_halRegSet(addr, value);

__CMD_ERROR:
    cmd_help(ret);
    
    return ret;
}
